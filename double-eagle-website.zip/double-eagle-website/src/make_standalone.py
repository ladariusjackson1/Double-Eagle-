#!/usr/bin/env python3
"""
Generate a fully self-contained copy of the site.

Every page gets its CSS and JS inlined and its links rewritten to relative
paths, so the files work when opened directly from a phone or desktop with no
web server involved. Deploy from site/ for production; this build is for
viewing and sharing.
"""
import pathlib, re, shutil

SRC = pathlib.Path("/home/claude/de/site")
OUT = pathlib.Path("/home/claude/de/standalone")
if OUT.exists():
    shutil.rmtree(OUT)
OUT.mkdir(parents=True)

css = (SRC / "assets/css/styles.css").read_text(encoding="utf-8")
js_main = (SRC / "assets/js/main.js").read_text(encoding="utf-8")
js_config = (SRC / "assets/js/config.js").read_text(encoding="utf-8")
favicon = (SRC / "assets/img/favicon.svg").read_text(encoding="utf-8")

# Inline the favicon as a data URI so there is no external file dependency.
import base64
fav_b64 = base64.b64encode(favicon.encode()).decode()
fav_uri = f"data:image/svg+xml;base64,{fav_b64}"

count = 0
for page in sorted(SRC.glob("*.html")):
    html = page.read_text(encoding="utf-8")

    # 1. Inline the stylesheet.
    html = html.replace(
        '<link rel="stylesheet" href="/assets/css/styles.css">',
        f"<style>\n{css}\n</style>")

    # 2. Inline both scripts.
    html = html.replace(
        '<script src="/assets/js/config.js"></script>',
        f"<script>\n{js_config}\n</script>")
    html = html.replace(
        '<script src="/assets/js/main.js" defer></script>',
        f"<script>\n{js_main}\n</script>")

    # 3. Favicon as data URI.
    html = html.replace('href="/assets/img/favicon.svg" type="image/svg+xml"',
                        f'href="{fav_uri}" type="image/svg+xml"')
    html = html.replace('<link rel="apple-touch-icon" href="/assets/img/favicon.svg">', "")

    # 4. Absolute internal links -> relative filenames, so file:// browsing works.
    html = html.replace('href="/"', 'href="index.html"')
    html = re.sub(r'href="/([a-z0-9\-]+\.html)', r'href="\1', html)

    (OUT / page.name).write_text(html, encoding="utf-8")
    count += 1

print(f"{count} self-contained pages written to {OUT}")
sizes = sorted(((p.stat().st_size, p.name) for p in OUT.glob("*.html")), reverse=True)
print(f"largest: {sizes[0][1]} at {sizes[0][0]//1024}KB")
