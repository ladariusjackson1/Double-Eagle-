#!/usr/bin/env python3
"""Real-browser QA. Serves site/ and drives Chromium across viewports."""
import http.server, socketserver, threading, functools, pathlib, sys, json
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent / "site"
SHOTS = pathlib.Path(__file__).resolve().parent.parent / "shots"
SHOTS.mkdir(exist_ok=True)
PORT = 8811

PAGES = ["/", "/the-core-four.html", "/pricing.html", "/about.html", "/faq.html",
         "/contact.html", "/book-a-call.html", "/profit-leak-audit.html",
         "/thank-you.html", "/privacy.html", "/terms.html"]

VIEWPORTS = [
    ("desktop", 1440, 900),
    ("laptop", 1280, 800),
    ("tablet", 768, 1024),
    ("iphone", 390, 844),
    ("android", 360, 800),
]

problems = []


class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass


def serve():
    handler = functools.partial(Handler, directory=str(ROOT))
    socketserver.TCPServer.allow_reuse_address = True
    httpd = socketserver.TCPServer(("127.0.0.1", PORT), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd


def main():
    serve()
    base = f"http://127.0.0.1:{PORT}"
    shots_taken = []

    with sync_playwright() as pw:
        browser = pw.chromium.launch(
            executable_path="/opt/google/chrome/chrome",
            args=["--no-sandbox", "--disable-dev-shm-usage"],
        )

        for vname, w, h in VIEWPORTS:
            ctx = browser.new_context(viewport={"width": w, "height": h},
                                      device_scale_factor=1,
                                      is_mobile=(vname in ("iphone", "android")),
                                      has_touch=(vname in ("iphone", "android")))
            page = ctx.new_page()
            errors = []
            def on_console(m):
                # Google Fonts is blocked by this sandbox's egress proxy; that is an
                # environment artifact, not a site defect. Ignore only those.
                if m.type == "error" and "403" not in m.text:
                    errors.append(m.text)
            page.on("console", on_console)
            page.on("pageerror", lambda e: errors.append(f"PAGEERROR {e}"))

            for path in PAGES:
                page.goto(base + path, wait_until="networkidle")
                page.wait_for_timeout(250)

                # Horizontal overflow check
                metrics = page.evaluate("""() => {
                    const de = document.documentElement;
                    const over = [];
                    document.querySelectorAll('body *').forEach(el => {
                        const r = el.getBoundingClientRect();
                        if (r.width > 0 && (r.right > de.clientWidth + 2 || r.left < -2)) {
                            const p = el.tagName.toLowerCase() + '.' + (el.className||'').toString().split(' ')[0];
                            if (!over.includes(p)) over.push(p);
                        }
                    });
                    return {
                        scrollW: de.scrollWidth,
                        clientW: de.clientWidth,
                        overflowing: over.slice(0, 6)
                    };
                }""")
                if metrics["scrollW"] > metrics["clientW"] + 2:
                    problems.append(
                        f"[{vname}] {path}: horizontal scroll "
                        f"({metrics['scrollW']}px > {metrics['clientW']}px) "
                        f"culprits={metrics['overflowing']}")

                # Tap target size on mobile
                if vname in ("iphone", "android"):
                    small = page.evaluate("""() => {
                        const bad = [];
                        document.querySelectorAll('a.btn, button, .nav a').forEach(el => {
                            const r = el.getBoundingClientRect();
                            if (r.width > 0 && r.height > 0 && r.height < 40) {
                                bad.push((el.textContent||'').trim().slice(0,28) + ' h=' + Math.round(r.height));
                            }
                        });
                        return bad.slice(0, 5);
                    }""")
                    if small:
                        problems.append(f"[{vname}] {path}: tap targets under 40px: {small}")

                if errors:
                    problems.append(f"[{vname}] {path}: console errors {errors[:3]}")
                    errors.clear()

                # Screenshots on two representative viewports
                if vname in ("desktop", "iphone"):
                    fn = SHOTS / f"{vname}{path.replace('/','_').replace('.html','') or '_home'}.png"
                    page.screenshot(path=str(fn), full_page=(path in ("/", "/pricing.html")))
                    shots_taken.append(fn.name)

            ctx.close()

        # ---------------- Interaction tests ----------------
        ctx = browser.new_context(viewport={"width": 1440, "height": 900})
        page = ctx.new_page()

        # FAQ accordion
        page.goto(base + "/faq.html", wait_until="networkidle")
        btn = page.locator(".faq-q").first
        panel_id = btn.get_attribute("aria-controls")
        if page.locator(f"#{panel_id}").is_visible():
            problems.append("FAQ: panel visible before click")
        btn.click(); page.wait_for_timeout(150)
        if not page.locator(f"#{panel_id}").is_visible():
            problems.append("FAQ: panel did not open on click")
        if btn.get_attribute("aria-expanded") != "true":
            problems.append("FAQ: aria-expanded not updated")
        btn.click(); page.wait_for_timeout(150)
        if page.locator(f"#{panel_id}").is_visible():
            problems.append("FAQ: panel did not close on second click")

        # Navigation links resolve (real HTTP status)
        page.goto(base + "/", wait_until="networkidle")
        hrefs = page.eval_on_selector_all(
            "a[href]", "els => [...new Set(els.map(e => e.getAttribute('href')))]")
        for h in hrefs:
            if h.startswith(("http", "mailto:", "tel:", "#")):
                continue
            r = page.request.get(base + h)
            if r.status >= 400:
                problems.append(f"link {h} -> HTTP {r.status}")

        # Mobile menu
        mctx = browser.new_context(viewport={"width": 390, "height": 844}, is_mobile=True, has_touch=True)
        mp = mctx.new_page()
        mp.goto(base + "/", wait_until="networkidle")
        if mp.locator("#primary-nav").is_visible():
            problems.append("mobile: nav visible before toggle")
        mp.locator(".nav-toggle").click(); mp.wait_for_timeout(250)
        if not mp.locator("#primary-nav").is_visible():
            problems.append("mobile: nav did not open")
        mp.screenshot(path=str(SHOTS / "iphone_menu_open.png"))
        mp.locator("#primary-nav a").first.click(); mp.wait_for_timeout(400)
        # Sticky CTA appears after scroll
        mp.goto(base + "/", wait_until="networkidle")
        mp.mouse.wheel(0, 1400); mp.wait_for_timeout(400)
        if not mp.locator(".sticky-cta").is_visible():
            problems.append("mobile: sticky CTA never appeared after scroll")
        mctx.close()

        # Form validation — empty submit must block and flag fields
        page.goto(base + "/profit-leak-audit.html", wait_until="networkidle")
        page.locator('form[data-form="lead-magnet"] button[type="submit"]').click()
        page.wait_for_timeout(250)
        if page.url.endswith("thank-you.html"):
            problems.append("form: empty submit navigated away instead of validating")
        if page.locator(".field.has-error").count() == 0:
            problems.append("form: no fields flagged on empty submit")
        if not page.locator(".form-status.is-visible").is_visible():
            problems.append("form: no status message shown on invalid submit")

        # Invalid email flagged
        page.fill("#lm-name", "Test Person")
        page.fill("#lm-email", "not-an-email")
        page.select_option("#lm-type", "Real estate agent")
        page.select_option("#lm-volume", "$500K – $1M")
        page.check('input[name="consent"]')
        page.locator('form[data-form="lead-magnet"] button[type="submit"]').click()
        page.wait_for_timeout(250)
        if page.locator("#lm-email").get_attribute("aria-invalid") != "true":
            problems.append("form: invalid email not flagged")

        # Valid submit with no endpoint must warn, not silently drop the lead
        page.fill("#lm-email", "test@example.com")
        page.locator('form[data-form="lead-magnet"] button[type="submit"]').click()
        page.wait_for_timeout(250)
        status = page.locator(".form-status").inner_text()
        if "endpoint" not in status.lower():
            problems.append(f"form: unconfigured endpoint did not warn (got: {status[:60]})")

        # Endpoint configured -> submits and redirects
        page.goto(base + "/profit-leak-audit.html", wait_until="networkidle")
        page.route("**/mock-endpoint", lambda route: route.fulfill(status=200, body="{}"))
        page.evaluate("window.DE_CONFIG.formEndpoint = '/mock-endpoint'")
        page.fill("#lm-name", "Test Person")
        page.fill("#lm-email", "test@example.com")
        page.select_option("#lm-type", "General contractor")
        page.select_option("#lm-volume", "$1M – $2M")
        page.check('input[name="consent"]')
        page.locator('form[data-form="lead-magnet"] button[type="submit"]').click()
        page.wait_for_url("**/thank-you.html*", timeout=5000)
        if "thank-you" not in page.url:
            problems.append("form: valid submit did not redirect to thank-you")

        # Analytics events fired
        events = page.evaluate("() => (window.dataLayer||[]).map(e => e.event)")
        for required in ("page_view", "lead_confirmed"):
            if required not in events:
                problems.append(f"analytics: '{required}' event missing (saw {events})")

        # CTA click tracking
        page.goto(base + "/", wait_until="networkidle")
        page.locator('a[data-cta="book-call"]').first.click()
        page.wait_for_load_state("networkidle")
        ctx.close()
        browser.close()

    print(f"Screenshots: {len(shots_taken)} saved to shots/")
    if problems:
        print(f"\n{len(problems)} BROWSER ISSUE(S):")
        for p in problems:
            print("  ✗", p)
        return 1
    print("All browser checks passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
