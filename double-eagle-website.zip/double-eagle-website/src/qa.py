#!/usr/bin/env python3
"""Static QA for the built site. Run: python3 src/qa.py"""
import pathlib, re, sys
from html.parser import HTMLParser

OUT = pathlib.Path(__file__).resolve().parent.parent / "site"
VOID = {"area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr"}
issues, checks = [], 0

def fail(page, msg):
    issues.append(f"{page}: {msg}")

class Doc(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack, self.unbalanced = [], []
        self.ids, self.aria_controls, self.aria_labelledby = set(), [], []
        self.links, self.imgs, self.h1, self.labels_for, self.inputs = [], [], 0, set(), []
        self.title, self.meta_desc, self.canonical = None, None, None
        self.in_title = False
        self.buttons_without_type = 0

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag not in VOID:
            self.stack.append(tag)
        if "id" in a: self.ids.add(a["id"])
        if "aria-controls" in a: self.aria_controls.append(a["aria-controls"])
        if "aria-labelledby" in a: self.aria_labelledby.append(a["aria-labelledby"])
        if tag == "a" and "href" in a: self.links.append(a["href"])
        if tag == "img": self.imgs.append(a)
        if tag == "h1": self.h1 += 1
        if tag == "title": self.in_title = True
        if tag == "label" and "for" in a: self.labels_for.add(a["for"])
        if tag in ("input","select","textarea"): self.inputs.append((tag, a))
        if tag == "button" and a.get("type") is None: self.buttons_without_type += 1
        if tag == "meta" and a.get("name") == "description": self.meta_desc = a.get("content","")
        if tag == "link" and a.get("rel") == "canonical": self.canonical = a.get("href","")

    def handle_endtag(self, tag):
        if tag in VOID: return
        if self.stack and self.stack[-1] == tag:
            self.stack.pop()
        elif tag in self.stack:
            while self.stack and self.stack.pop() != tag:
                pass
            self.unbalanced.append(tag)
        else:
            self.unbalanced.append(f"stray </{tag}>")

    def handle_data(self, data):
        if self.in_title:
            self.title = data.strip(); self.in_title = False

pages = sorted(OUT.glob("*.html"))
if not pages:
    print("No pages built."); sys.exit(1)

existing = {p.name for p in pages} | {"sitemap.xml", "robots.txt"}

for p in pages:
    html = p.read_text(encoding="utf-8")
    name = p.name
    d = Doc(); d.feed(html); d.close()
    checks += 1

    # 1. Template placeholders must all be substituted
    for ph in re.findall(r"__[A-Z_]+__", html):
        fail(name, f"unsubstituted placeholder {ph}")

    # 2. Tag balance
    if d.unbalanced: fail(name, f"unbalanced tags: {d.unbalanced[:5]}")
    if d.stack: fail(name, f"unclosed tags at EOF: {d.stack[:5]}")

    # 3. SEO fundamentals
    if not d.title: fail(name, "missing <title>")
    elif len(d.title) > 70: fail(name, f"title too long ({len(d.title)} chars)")
    if not d.meta_desc: fail(name, "missing meta description")
    elif not (50 <= len(d.meta_desc) <= 175): fail(name, f"meta description length {len(d.meta_desc)}")
    if not d.canonical: fail(name, "missing canonical")
    if d.h1 != 1: fail(name, f"expected exactly 1 <h1>, found {d.h1}")

    # 4. Internal links resolve
    for href in d.links:
        if href.startswith(("http://","https://","mailto:","tel:","#")): continue
        target = href.split("#")[0].split("?")[0].lstrip("/")
        if target == "" : continue  # "/" -> index
        if target not in existing:
            fail(name, f"broken internal link -> {href}")

    # 5. ARIA references resolve
    for ref in d.aria_controls:
        if ref not in d.ids: fail(name, f"aria-controls='{ref}' has no matching id")
    for ref in d.aria_labelledby:
        if ref not in d.ids: fail(name, f"aria-labelledby='{ref}' has no matching id")

    # 6. Duplicate ids
    ids_all = re.findall(r'\sid="([^"]+)"', html)
    dupes = {i for i in ids_all if ids_all.count(i) > 1}
    if dupes: fail(name, f"duplicate ids: {sorted(dupes)}")

    # 7. Every form control has a label or aria-label
    for tag, a in d.inputs:
        if a.get("type") in ("hidden",): continue
        _id = a.get("id")
        if _id and _id in d.labels_for: continue
        if a.get("aria-label"): continue
        # checkbox wrapped in <label class="consent"> is acceptable
        if a.get("type") == "checkbox": continue
        fail(name, f"<{tag} name={a.get('name')}> has no associated label")

    # 8. Images need alt
    for a in d.imgs:
        if "alt" not in a: fail(name, f"<img src={a.get('src')}> missing alt")

    # 9. Buttons must declare type (prevents implicit form submit)
    if d.buttons_without_type:
        fail(name, f"{d.buttons_without_type} <button> without type attribute")

    # 10. Every page must offer a conversion path
    if name not in ("privacy.html","terms.html","thank-you.html"):
        if "profit-leak-audit.html" not in html and "book-a-call.html" not in html:
            fail(name, "no primary CTA found on page")

# 11. Referenced local assets exist
root = OUT
for p in pages:
    html = p.read_text(encoding="utf-8")
    for asset in set(re.findall(r'(?:src|href)="(/assets/[^"]+)"', html)):
        if not (root / asset.lstrip("/")).exists():
            fail(p.name, f"missing asset {asset}")

# 12. Sitemap + robots
if not (OUT/"sitemap.xml").exists(): fail("sitemap.xml", "missing")
if not (OUT/"robots.txt").exists(): fail("robots.txt", "missing")

print(f"Checked {checks} pages.")
if issues:
    print(f"\n{len(issues)} ISSUE(S):")
    for i in issues: print("  ✗", i)
    sys.exit(1)
print("All checks passed.")
