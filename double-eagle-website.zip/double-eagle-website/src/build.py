#!/usr/bin/env python3
"""
Double Eagle Financial — static site builder.

Renders each fragment in src/pages/ into src/templates/base.html so the
header, footer, nav and <head> stay identical across every page.

Usage:  python3 src/build.py
Output: site/*.html  (plus sitemap.xml and robots.txt)
"""

import datetime
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
OUT = ROOT / "site"
BASE_URL = "https://www.doubleeaglefinancial.com"

ORG_SCHEMA = """<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "AccountingService",
  "name": "Double Eagle Financial LLC",
  "description": "Deal-level and job-level bookkeeping, cash flow reporting and tax-readiness for real estate agents and general contractors.",
  "url": "https://www.doubleeaglefinancial.com",
  "email": "hello@doubleeaglefinancial.com",
  "areaServed": { "@type": "Country", "name": "United States" },
  "address": { "@type": "PostalAddress", "addressLocality": "Memphis", "addressRegion": "TN", "addressCountry": "US" },
  "knowsAbout": ["Real estate agent bookkeeping", "Contractor job costing", "Commission tracking", "Cash flow forecasting"],
  "makesOffer": [
    { "@type": "Offer", "name": "Foundation", "price": "650", "priceCurrency": "USD",
      "itemOffered": { "@type": "Service", "name": "The Core Four Profit System — Foundation" } },
    { "@type": "Offer", "name": "Advisor", "price": "950", "priceCurrency": "USD",
      "itemOffered": { "@type": "Service", "name": "The Core Four Profit System — Advisor" } },
    { "@type": "Offer", "name": "CFO Partner", "price": "1650", "priceCurrency": "USD",
      "itemOffered": { "@type": "Service", "name": "The Core Four Profit System — CFO Partner" } }
  ]
}
</script>"""

# key -> metadata. `nav` is the label shown in the main nav (None = hidden).
PAGES = {
    "home": {
        "file": "index.html",
        "slug": "/",
        "nav": None,
        "title": "Bookkeeping for Agents & Contractors | Double Eagle Financial",
        "description": "Know your real profit on every deal and every job by the 10th of the month — with taxes already handled. Bookkeeping built for real estate agents and general contractors.",
        "schema": ORG_SCHEMA,
        "priority": "1.0",
    },
    "offer": {
        "file": "the-core-four.html",
        "slug": "/the-core-four.html",
        "nav": "The Core Four",
        "title": "The Core Four Profit System | Double Eagle Financial",
        "description": "A complete financial system for agents and contractors: reconciled books, profit per deal and per job, 13-week cash flow, year-round tax readiness. By the 10th or free.",
        "priority": "0.9",
    },
    "pricing": {
        "file": "pricing.html",
        "slug": "/pricing.html",
        "nav": "Pricing",
        "title": "Pricing — Foundation, Advisor & CFO Partner | Double Eagle Financial",
        "description": "Transparent monthly pricing: Foundation $650, Advisor $950, CFO Partner $1,650. One-time Cleanup Sprint from $750. No long-term contract.",
        "priority": "0.9",
    },
    "about": {
        "file": "about.html",
        "slug": "/about.html",
        "nav": "About",
        "title": "About Double Eagle Financial | Bookkeeping Built for One Niche",
        "description": "Why we only work with real estate agents and general contractors, how we work, and what you can hold us to.",
        "priority": "0.6",
    },
    "faq": {
        "file": "faq.html",
        "slug": "/faq.html",
        "nav": "FAQ",
        "title": "Frequently Asked Questions | Double Eagle Financial",
        "description": "Pricing, onboarding, QuickBooks, cleanup, contracts, taxes, data security, communication and cancellation — answered plainly.",
        "priority": "0.7",
    },
    "contact": {
        "file": "contact.html",
        "slug": "/contact.html",
        "nav": "Contact",
        "title": "Contact Double Eagle Financial",
        "description": "Send a message and get a reply within one business day, or book a 20-minute fit call.",
        "priority": "0.5",
    },
    "book": {
        "file": "book-a-call.html",
        "slug": "/book-a-call.html",
        "nav": None,
        "title": "Book a 20-Minute Fit Call | Double Eagle Financial",
        "description": "A short, structured call to see whether The Core Four Profit System fits your business. No pitch deck, no pressure.",
        "priority": "0.9",
    },
    "lead-magnet": {
        "file": "profit-leak-audit.html",
        "slug": "/profit-leak-audit.html",
        "nav": None,
        "title": "Free Profit Leak Audit for Agents & GCs | Double Eagle",
        "description": "A one-page audit of where your money is actually going — two or three specific findings from your own numbers. Free, no obligation.",
        "priority": "0.9",
    },
    "thank-you": {
        "file": "thank-you.html",
        "slug": "/thank-you.html",
        "nav": None,
        "title": "Request received | Double Eagle Financial",
        "description": "We've received your request and will be in touch within one business day.",
        "robots": "noindex, follow",
        "sitemap": False,
    },
    "privacy": {
        "file": "privacy.html",
        "slug": "/privacy.html",
        "nav": None,
        "title": "Privacy Policy | Double Eagle Financial",
        "description": "What information we collect, why we collect it, how we store it, and how to have it deleted.",
        "priority": "0.3",
    },
    "terms": {
        "file": "terms.html",
        "slug": "/terms.html",
        "nav": None,
        "title": "Terms of Service | Double Eagle Financial",
        "description": "The terms that govern use of this website and our bookkeeping services.",
        "priority": "0.3",
    },
}

NAV_ORDER = ["offer", "pricing", "about", "faq", "contact"]


def build_nav(current_key: str) -> str:
    items = []
    for key in NAV_ORDER:
        page = PAGES[key]
        current = ' aria-current="page"' if key == current_key else ""
        items.append(f'<a href="{page["slug"]}"{current}>{page["nav"]}</a>')
    return "\n      ".join(items)


def main() -> int:
    base = (SRC / "templates" / "base.html").read_text(encoding="utf-8")
    year = str(datetime.date.today().year)
    today = datetime.date.today().isoformat()
    OUT.mkdir(parents=True, exist_ok=True)
    built = []

    for key, meta in PAGES.items():
        fragment_path = SRC / "pages" / f"{key}.html"
        if not fragment_path.exists():
            print(f"  MISSING fragment: {fragment_path}", file=sys.stderr)
            return 1
        body = fragment_path.read_text(encoding="utf-8")

        html = (
            base.replace("__TITLE__", meta["title"])
            .replace("__DESCRIPTION__", meta["description"])
            .replace("__BASEURL__", BASE_URL)
            .replace("__SLUG__", "" if meta["slug"] == "/" else meta["slug"])
            .replace("__ROBOTS__", meta.get("robots", "index, follow"))
            .replace("__SCHEMA__", meta.get("schema", ""))
            .replace("__PAGEKEY__", key)
            .replace("__NAV__", build_nav(key))
            .replace("__BODY__", body)
            .replace("__YEAR__", year)
        )

        # Collapse blank lines left by empty replacements.
        html = re.sub(r"\n{3,}", "\n\n", html)
        (OUT / meta["file"]).write_text(html, encoding="utf-8")
        built.append(meta["file"])
        print(f"  built  site/{meta['file']}")

    # sitemap.xml
    urls = []
    for meta in PAGES.values():
        if meta.get("sitemap") is False:
            continue
        loc = BASE_URL + ("" if meta["slug"] == "/" else meta["slug"])
        if meta["slug"] == "/":
            loc = BASE_URL + "/"
        urls.append(
            f"  <url>\n    <loc>{loc}</loc>\n    <lastmod>{today}</lastmod>\n"
            f"    <priority>{meta.get('priority', '0.5')}</priority>\n  </url>"
        )
    sitemap = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
        + "\n".join(urls)
        + "\n</urlset>\n"
    )
    (OUT / "sitemap.xml").write_text(sitemap, encoding="utf-8")

    (OUT / "robots.txt").write_text(
        f"User-agent: *\nAllow: /\nDisallow: /thank-you.html\n\nSitemap: {BASE_URL}/sitemap.xml\n",
        encoding="utf-8",
    )

    print(f"\n  {len(built)} pages + sitemap.xml + robots.txt written to site/")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
